import React, { useEffect, useState } from 'react'
import { get, post } from './api'
import ProjectList from './components/ProjectList'
import CreateProject from './components/CreateProject'

export default function App(){
  const [projects, setProjects] = useState<any[]>([]);
  async function load(){
    const ps = await get('/projects');
    setProjects(ps);
  }
  useEffect(()=>{ load() },[])
  return (
    <div style={{padding:20,maxWidth:900,margin:'0 auto'}}>
      <h1>Crowdfunding (Demo)</h1>
      <CreateProject onCreated={load} />
      <ProjectList projects={projects} onBacked={load} />
    </div>
  )
}
