import React, { useState } from 'react'
import { post } from '../api'

export default function CreateProject({ onCreated }: { onCreated?: ()=>void }){
  const [title,setTitle]=useState('');
  const [desc,setDesc]=useState('');
  const [goal,setGoal]=useState(1000);
  async function submit(){
    // For demo: this uses a token from localStorage if available
    const token = localStorage.getItem('token');
    await post('/projects', { title, description: desc, goal, token });
    setTitle(''); setDesc(''); setGoal(1000);
    onCreated && onCreated();
  }
  return (
    <div style={{border:'1px solid #ddd',padding:12,borderRadius:8,marginBottom:12}}>
      <h3>Create Project</h3>
      <input value={title} onChange={e=>setTitle(e.target.value)} placeholder="Title" />
      <br/>
      <textarea value={desc} onChange={e=>setDesc(e.target.value)} placeholder="Description" />
      <br/>
      <input type="number" value={goal} onChange={e=>setGoal(Number(e.target.value))} />
      <br/>
      <button onClick={submit}>Create</button>
    </div>
  )
}
