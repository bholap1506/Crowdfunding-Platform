import React from 'react'
import { post } from '../api'

export default function ProjectList({ projects, onBacked }: { projects:any[], onBacked?: ()=>void }){
  async function back(id:string){
    const name = prompt('Your name') || 'Anonymous';
    const amt = Number(prompt('Amount') || '0');
    await post(`/projects/${id}/back`, { backer_name: name, amount: amt });
    onBacked && onBacked();
  }
  return (
    <div>
      <h3>Projects</h3>
      {projects.map(p=> (
        <div key={p.id} style={{border:'1px solid #eee',padding:10,borderRadius:8,marginBottom:8}}>
          <h4>{p.title}</h4>
          <div>Goal: {p.goal} • Funded: {p.funded}</div>
          <p>{p.description}</p>
          <button onClick={()=>back(p.id)}>Back</button>
        </div>
      ))}
    </div>
  )
}
