# Crowdfunding Platform (Monorepo)

This monorepo contains a simple but working crowdfunding platform using:
- React + TypeScript frontend (Vite)
- Node.js + TypeScript backend (Express)
- PostgreSQL database
- Java Spring Boot analytics microservice
- Docker & docker-compose for local development

## Quick start (requires Docker)

1. Clone the repo and `cd crowdfunding-platform`.
2. Create `.env` in `server-node-ts/` by copying `.env.example` and filling values.
3. Start everything:

```bash
docker-compose up --build
```

4. Frontend: http://localhost:5173
   Backend API: http://localhost:4000/api
   Analytics: http://localhost:5000

## Notes
- This demo is educational. Do not use in production without tightening security.
- Passwords are hashed, JWTs are used for authentication, but there is no email verification or payment gateway (payments are simulated).
