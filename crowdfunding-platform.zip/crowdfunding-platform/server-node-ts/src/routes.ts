import express from 'express';
import { query } from './db';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';
import { v4 as uuidv4 } from 'uuid';

dotenv.config();
const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || 'secret';
const SALT_ROUNDS = 10;

// Register
router.post('/auth/register', async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ error: 'Missing' });
  const hash = await bcrypt.hash(password, SALT_ROUNDS);
  try {
    await query('INSERT INTO users (id, username, password_hash) VALUES ($1, $2, $3)', [uuidv4(), username, hash]);
    res.json({ ok: true });
  } catch (e: any) {
    console.error(e);
    res.status(500).json({ error: e.message });
  }
});

// Login
router.post('/auth/login', async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ error: 'Missing' });
  const r = await query('SELECT id, password_hash FROM users WHERE username = $1', [username]);
  const row = r.rows[0];
  if (!row) return res.status(401).json({ error: 'Invalid' });
  const ok = await bcrypt.compare(password, row.password_hash);
  if (!ok) return res.status(401).json({ error: 'Invalid' });
  const token = jwt.sign({ userId: row.id, username }, JWT_SECRET, { expiresIn: '8h' });
  res.json({ token });
});

// Create project
router.post('/projects', async (req, res) => {
  const { title, description, goal, token } = req.body;
  if (!title || !goal) return res.status(400).json({ error: 'Missing' });
  let userId: string | null = null;
  try {
    const payload: any = jwt.verify(token, JWT_SECRET);
    userId = payload.userId;
  } catch (e) { return res.status(401).json({ error: 'Invalid token' }); }
  try {
    const id = uuidv4();
    await query('INSERT INTO projects (id, owner_id, title, description, goal) VALUES ($1,$2,$3,$4,$5)', [id, userId, title, description || null, goal]);
    res.json({ id });
  } catch (e: any) { console.error(e); res.status(500).json({ error: e.message }); }
});

// List projects
router.get('/projects', async (req, res) => {
  const r = await query(`SELECT p.*, COALESCE(SUM(pl.amount),0) AS funded FROM projects p LEFT JOIN pledges pl ON pl.project_id = p.id GROUP BY p.id ORDER BY p.created_at DESC`);
  res.json(r.rows);
});

// Get project by id
router.get('/projects/:id', async (req, res) => {
  const id = req.params.id;
  const p = await query('SELECT * FROM projects WHERE id = $1', [id]);
  if (!p.rows[0]) return res.status(404).json({ error: 'Not found' });
  const pledges = await query('SELECT id, backer_name, amount, created_at FROM pledges WHERE project_id = $1 ORDER BY created_at DESC', [id]);
  const funded = await query('SELECT COALESCE(SUM(amount),0) AS funded FROM pledges WHERE project_id = $1', [id]);
  res.json({ project: p.rows[0], pledges: pledges.rows, funded: funded.rows[0].funded });
});

// Back a project
router.post('/projects/:id/back', async (req, res) => {
  const id = req.params.id;
  const { backer_name, amount } = req.body;
  if (!backer_name || !amount) return res.status(400).json({ error: 'Missing' });
  try {
    await query('INSERT INTO pledges (id, project_id, backer_name, amount) VALUES ($1,$2,$3,$4)', [uuidv4(), id, backer_name, amount]);
    res.json({ ok: true });
  } catch (e: any) { console.error(e); res.status(500).json({ error: e.message }); }
});

// Withdraw (owner only, simulated)
router.post('/projects/:id/withdraw', async (req, res) => {
  const id = req.params.id;
  const { token } = req.body;
  let userId: string | null = null;
  try { const payload: any = jwt.verify(token, JWT_SECRET); userId = payload.userId; } catch (e) { return res.status(401).json({ error: 'Invalid token' }); }
  const p = await query('SELECT * FROM projects WHERE id = $1', [id]);
  const proj = p.rows[0];
  if (!proj) return res.status(404).json({ error: 'Not found' });
  if (proj.owner_id !== userId) return res.status(403).json({ error: 'Not owner' });
  const funded = await query('SELECT COALESCE(SUM(amount),0) as funded FROM pledges WHERE project_id = $1', [id]);
  if (Number(funded.rows[0].funded) < Number(proj.goal)) return res.status(400).json({ error: 'Goal not reached' });
  await query('UPDATE projects SET withdrawn = true WHERE id = $1', [id]);
  res.json({ ok: true, message: 'Withdrawn (simulated)' });
});

export default router;
