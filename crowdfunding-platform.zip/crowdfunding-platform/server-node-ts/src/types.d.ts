export interface ProjectRow {
  id: string;
  owner_id: string;
  title: string;
  description: string|null;
  goal: number;
  withdrawn: boolean;
  created_at: string;
}
